
public class Impresora implements Runnable {

    // Atributos que identifican la impresora y su trabajo.
    private final String nombre;
    private final int numeroPaginas;

    // El constructor recibe el nombre y las páginas que debe imprimir.
    public Impresora(String nombre, int numeroPaginas) {
        this.nombre = nombre;
        this.numeroPaginas = numeroPaginas;
    }

    // run() contiene el trabajo que ejecutará el hilo.
    @Override
    public void run() {

        // Recorremos todas las páginas desde la primera hasta la última.
        for (int pagina = 1; pagina <= numeroPaginas; pagina++) {

            // Mostramos el progreso de la impresión.
            System.out.println(
                    nombre + " está imprimiendo la página "
                            + pagina + " de " + numeroPaginas
            );

            try {
                // Simulamos que imprimir una página tarda un segundo.
                Thread.sleep(1000);

            } catch (InterruptedException e) {

                // Restauramos el estado de interrupción del hilo, si se da el caso de que existe esta.
                Thread.currentThread().interrupt();

                // Avisamos de la interrupción y detenemos esta tarea, si se da el caso.
                System.out.println(nombre + " ha sido interrumpida.");
                return;
            }
        }

        // Este mensaje solo aparece si se imprimen todas las páginas.
        System.out.println(nombre + " ha terminado de imprimir.");
    }
}
